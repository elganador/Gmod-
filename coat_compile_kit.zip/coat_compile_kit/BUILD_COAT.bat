@echo off
setlocal
set GMOD=D:\SteamLibrary\steamapps\common\GarrysMod
set HERE=%~dp0
set STUDIOMDL=%GMOD%\bin\studiomdl.exe
if not exist "%STUDIOMDL%" set STUDIOMDL=%GMOD%\bin\win64\studiomdl.exe
if not exist "%STUDIOMDL%" (
  echo Could not find studiomdl.exe in %GMOD%\bin. Edit the GMOD line at the top of this file.
  pause & exit /b 1
)
echo Compiling the coat...
"%STUDIOMDL%" -nop4 -game "%GMOD%\garrysmod" "%HERE%coat.qc"
if errorlevel 1 ( echo Compile FAILED - copy the text above and send it to Claude. & pause & exit /b 1 )
set OUT=%HERE%zipme
rmdir /s /q "%OUT%" 2>nul
mkdir "%OUT%\models\player\sgcoat09"
mkdir "%OUT%\materials\models\sgcoat09"
copy "%GMOD%\garrysmod\models\player\sgcoat09\sage_coat.*" "%OUT%\models\player\sgcoat09\" >nul
copy "%HERE%materials\models\sgcoat09\*" "%OUT%\materials\models\sgcoat09\" >nul
del "%HERE%sage_coat9.zip" 2>nul
powershell -NoProfile -Command "Add-Type -A System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::CreateFromDirectory('%OUT%', '%HERE%sage_coat9.zip', [IO.Compression.CompressionLevel]::NoCompression, $false)"
echo.
echo Done! Upload sage_coat9.zip (next to this file) to your GitHub repo.
pause
