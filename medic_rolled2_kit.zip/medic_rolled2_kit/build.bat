@echo off
set GMOD=D:\SteamLibrary\steamapps\common\GarrysMod
set HERE=%~dp0
if not exist "%HERE%medic.qc" (
  echo.
  echo  You ran build.bat from INSIDE the zip. Right-click the zip, choose "Extract All", then run build.bat from the extracted folder.
  echo.
  pause
  exit /b
)
if not exist "%GMOD%\bin\studiomdl.exe" (
  echo  Could not find studiomdl.exe at %GMOD%\bin - edit the GMOD line at the top of build.bat.
  pause
  exit /b
)
echo Compiling, please wait...
"%GMOD%\bin\studiomdl.exe" -nop4 -nox360 -game "%GMOD%\garrysmod" "%HERE%medic.qc" > "%HERE%compile_log.txt" 2>&1
set OUT=%HERE%zipme
rmdir /s /q "%OUT%" 2>nul
mkdir "%OUT%\models\player\medcsuit3"
mkdir "%OUT%\materials\models\medcsuit3"
copy "%GMOD%\garrysmod\models\player\medcsuit3\medic_rolled2.*" "%OUT%\models\player\medcsuit3\" >nul
copy "%HERE%*.vmt" "%OUT%\materials\models\medcsuit3\" >nul
copy "%HERE%*.vtf" "%OUT%\materials\models\medcsuit3\" >nul
del "%HERE%medic_rolled2.zip" 2>nul
powershell -NoProfile -Command "Add-Type -A System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::CreateFromDirectory('%OUT%', '%HERE%medic_rolled2.zip', [IO.Compression.CompressionLevel]::NoCompression, $false)"
echo DONE >> "%HERE%compile_log.txt"
if exist "%HERE%medic_rolled2.zip" (
  echo.
  echo  SUCCESS: medic_rolled2.zip was created. Upload THAT file to GitHub ^(not the kit^).
  explorer /select,"%HERE%medic_rolled2.zip"
) else (
  echo.
  echo  FAILED - send compile_log.txt to Claude.
  notepad "%HERE%compile_log.txt"
)
pause
