
player_manager.AddValidModel( "chronos",   "models/player/captainPawn/chronos.mdl" );
list.Set( "PlayerOptionsModel", "chronos", "models/player/captainPawn/chronos.mdl" );
