@echo off
set GMOD=D:\SteamLibrary\steamapps\common\GarrysMod
set HERE=%~dp0
"%GMOD%\bin\studiomdl.exe" -nop4 -nox360 -game "%GMOD%\garrysmod" "%HERE%medic.qc" > "%HERE%compile_log.txt" 2>&1
set OUT=%HERE%zipme
rmdir /s /q "%OUT%" 2>nul
mkdir "%OUT%\models\player\medcsuit2"
mkdir "%OUT%\materials\models\medcsuit2"
copy "%GMOD%\garrysmod\models\player\medcsuit2\medic_rolled.*" "%OUT%\models\player\medcsuit2\" >nul
copy "%HERE%*.vmt" "%OUT%\materials\models\medcsuit2\" >nul
copy "%HERE%*.vtf" "%OUT%\materials\models\medcsuit2\" >nul
del "%HERE%medic_rolled.zip" 2>nul
powershell -NoProfile -Command "Add-Type -A System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::CreateFromDirectory('%OUT%', '%HERE%medic_rolled.zip', [IO.Compression.CompressionLevel]::NoCompression, $false)"
echo DONE >> "%HERE%compile_log.txt"
