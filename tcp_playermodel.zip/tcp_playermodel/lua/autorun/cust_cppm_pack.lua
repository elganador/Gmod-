player_manager.AddValidModel( "(CPF) Police Unit07", "models/player/cpf/police/police_07.mdl" )
list.Set( "PlayerOptionsModel", "(CPF) Police Unit07", "models/player/cpf/police/police_07.mdl" )
player_manager.AddValidHands( "(CPF) Police Unit07", "models/weapons/c_arms_police_cpf.mdl", 0 ,"00000000" )

player_manager.AddValidModel( "(CPF) Police Unit07 (Masked)", "models/player/cpf/police/police_masked07.mdl" )
list.Set( "PlayerOptionsModel", "(CPF) Police Unit07 (Masked)", "models/player/cpf/police/police_masked07.mdl" )
player_manager.AddValidHands( "(CPF) Police Unit07 (Masked)", "models/weapons/c_arms_police_cpf.mdl", 0 ,"00000000" )

player_manager.AddValidModel( "(CPF) Police Unit07 (Gasmask)", "models/player/cpf/police/police_gasmask07.mdl" )
list.Set( "PlayerOptionsModel", "(CPF) Police Unit07 (Gasmask)", "models/player/cpf/police/police_gasmask07.mdl" )
player_manager.AddValidHands( "(CPF) Police Unit07 (Gasmask)", "models/weapons/c_arms_police_cpf.mdl", 0 ,"00000000" )

hook.Add("PreDrawPlayerHands", "(c_arms_police_cpf)", function(hands, vm, ply, wpn)
if IsValid(hands) and hands:GetModel() == "models/weapons/c_arms_police_cpf.mdl" then

hands:SetSkin(ply:GetSkin())
end
// to change the c_hand skingroup according to the model's skingroup

if ply:GetBodygroup(1) == 1 then
hands:SetBodygroup(0, 1)
end

if ply:GetBodygroup(4) == 1 then
hands:SetBodygroup(1, 1)
end

end)